# Replication data -- "Do Voters Punish Political Instability?"

District-level electoral panel for Peru (2006--2026) behind the paper *Do Voters Punish Political
Instability? Attribution, Electoral Subversion, and Material Disruption in Peru* (Carlos Cesar Chavez
Padilla, 2026). The paper compares districts targeted by Fuerza Popular's 2021 vote-annulment offensive
with profile-matched controls, and districts crossed by the paralyzed Lava Jato road corridors.

## What this is
- 20 district- and province-level CSVs: the estimation universe, the primary and first-round
  outcomes, the 36-specification robustness curve, the first-round block decomposition and offensive-
  intensity panel, the two mechanism tests (intensity and runoff absorption), the Lava Jato corridor
  exposure, and the Conley spatial-HAC inference table.
- `DATA_DICTIONARY.md` documents every file and column.

## Sources and privacy
Built entirely from public sources: ONPE electoral results (2006--2026), JNE/INFOgob annulment-petition
records and the 2021 presidential baseline, and the INEI 2017 census. Every table is a geographic
aggregate keyed on the ONPE district code. **No personal data is included** -- no names, identifiers, or
individual-level records. INEI and ONPE use different district codings; the electoral key is the ONPE
UBIGEO throughout.

## License
Released under CC BY 4.0.

## Citation
Chavez Padilla, Carlos Cesar. 2026. "Do Voters Punish Political Instability? Attribution, Electoral
Subversion, and Material Disruption in Peru." Working paper.
