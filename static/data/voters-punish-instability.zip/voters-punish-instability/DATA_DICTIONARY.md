# Data dictionary -- Do Voters Punish Political Instability? (Peru)

District- and province-level datasets derived from public ONPE (electoral results), JNE/INFOgob
(annulment petitions and 2021 baseline), and INEI (2017 census) sources. No personal data: every
row is a geographic aggregate keyed on the ONPE district code (UBIGEO). Screened for person-level
fields before release.

### `data/fp_control_impugnable.csv`
Estimation universe: treated (FP-petitioned) and impugnable control districts, propensity and group label.  (1874 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo

### `data/t4_castigo_2v.csv`
Primary outcome: change in the actor's two-way runoff (Keiko) share 2021->2026, by group.  (1874 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo, keiko_2v26, protesta_2v26, votos_emitidos_estim, dKeiko_2v, dProtesta

### `data/t4_castigo_1v.csv`
First-round outcome: change in first-round share 2021->2026, by group.  (1874 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo, keiko_1v21, keiko_1v26, dKeiko_1v

### `data/t4_robustez.csv`
Per-district outcomes and covariates for the robustness battery (six vote measures).  (1398 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo, keiko_2v26, protesta_2v26, votos_emitidos_estim, dKeiko_2v, dProtesta, dKeiko_1v, tratado, prov, keiko_2v16, dKeiko_1621

### `data/t4_knobs.csv`
36-specification curve: estimate and SE under each electorate cutoff x trim x covariate set.  (36 rows)
Columns: cut, trim, feats, n_tr, ab, se, t, p

### `data/t4_blocks.csv`
First-round vote in comparable political blocks (FP, non-FP right, RLA, left), 2021 and 2026.  (1398 rows)
Columns: UBIGEO, grupo, tratado, dKeiko_2v, dProtesta, keiko_2v21, keiko_2v16, turnout, log_elec, rural, sFP_21, sNonFPright_21, sRLA_21, sOtherRight_21, sLeft_21, sFP_26, sNonFPright_26, sRLA_26, sOtherRight_26, sLeft_26, d_sFP, d_sNonFPright, d_sRLA, d_sOtherRight, d_sLeft, turnout_2026, dTurnout

### `data/t4_blocks_2016.csv`
Block shares back to 2016 plus province id, for the first-round pre-trend window.  (1398 rows)
Columns: UBIGEO, grupo, tratado, sFP_21, sNonFPright_21, sLeft_21, sFP_16, sNonFPright_16, sLeft_16, pre_sFP, pre_sNonFPright, pre_sLeft, prov

### `data/t4_threatened.csv`
Offensive intensity: threatened-vote share (margin in petitioned tally sheets) per district.  (2082 rows)
Columns: UBIGEO, valid_d, n_actas, n_fp_mesas, threat_margin, threatened_votes, threatened_share_actas

### `data/t4_dosis.csv`
Dose-response inputs: petition count and contested-sheet share per district.  (1398 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo, keiko_2v26, protesta_2v26, votos_emitidos_estim, dKeiko_2v, dProtesta, dKeiko_1v, fp_pedidos, log_ped, prov, tier

### `data/t4_s9_mechanisms.csv`
Five candidate moderators (polarization, development, information, education, clientelism) per district.  (1398 rows)
Columns: UBIGEO, castillo, fujimori, blanco, nulo, votos, electores, n_actas, share_castillo, keiko_2v21, turnout, protesta_2v21, electores_x_acta, ubigeo, fp_impugno, log_elec, rural, pscore, grupo, keiko_2v26, protesta_2v26, votos_emitidos_estim, dKeiko_2v, dProtesta, pct_internet, avg_years_education, pct_urban, pct_rural, pct_indigenous, mean_age, total_population, transfer_2020, T, prov, polariz, transfer_pc

### `data/fp_nulidad_distrito_x_voto.csv`
District-level FP and PL annulment-petition counts merged to the 2021 vote.  (2082 rows)
Columns: ubigeo, castillo, fujimori, n_actas, UBIGEO, share_castillo, fp_pedidos, pl_pedidos, fp_impugno, pl_impugno

### `data/fp_nulidad_jee_x_voto.csv`
JEE-province annulment tallies (petitions, dismissed) joined to the vote.  (273 rows)
Columns: departamento, provincia, castillo, fujimori, n_actas, electores, share_castillo, prov_n, pedidos, infundados, improcedentes, fp_impugno, pedidos_x_acta

### `data/district_lavajato_core_exposure.csv`
Districts crossed by the core Lava Jato corridors with 2016 construction status.  (240 rows)
Columns: UBIGEO, estado_2016, corridors, n_corridors, km_road, source_tier

### `data/v1dose_results.csv`
Intensity test: FP slope, left mirror, asymmetry, clustered SE and randomization-inference p.  (3 rows)
Columns: spec, beta, se, p, ri_p, n

### `data/v1dose_bins_FP.csv`
Adjusted first-round FP change by dose tercile.  (4 rows)
Columns: terc, b, se, lo, hi

### `data/v1dose_bins_Left.csv`
Adjusted first-round left change by dose tercile.  (4 rows)
Columns: terc, b, se, lo, hi

### `data/recovery_results.csv`
Absorption test: common reconstitution slope and differential return theta.  (3 rows)
Columns: spec, coef, se, p, ri_p, n

### `data/recovery_bins_0.csv`
Adjusted runoff reconstitution by erosion tercile, control districts.  (3 rows)
Columns: eterc, b, se, lo, hi

### `data/recovery_bins_1.csv`
Adjusted runoff reconstitution by erosion tercile, targeted districts.  (3 rows)
Columns: eterc, b, se, lo, hi

### `data/referee_conley_table.csv`
Conley spatial-HAC standard errors at 50-500 km for the primary estimate.  (8 rows)
Columns: method, raw_tau, raw_se, ancova_tau, ancova_se, raw_se_rep, ancova_se_rep, raw_bart, ancova_bart

