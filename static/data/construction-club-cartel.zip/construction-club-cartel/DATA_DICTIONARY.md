# Data Dictionary

### indecopi_080_process_union_all_exhibits.csv  (78 tenders)
- `process_id_master` — canonical tender code (type, number, year, MTC sub-unit)
- `process_id_aliases`, `n_aliases` — alternate code notations merged into this tender
- `n_exhibits`, `source_exhibits` — number and identity of firm exhibits documenting the tender (CSP18 Cosapi, OBN10 Obrainsa, JJC01 JJC)
- `process_year`, `project_name` — year and road work
- `observed_winner`, `winner_members` — winning consortium and its member firms
- `reference_value`, `offered_value`, `value_conflict` — referential and offered amounts; flag if exhibits disagree
- `cartel_designated_winner`, `initial_observed_winner`, `final_observed_winner`, `contracted_winner` — winner chronology
- `winner_changed_after_appeal`, `winner_conflict_resolved`, `chronology_note` — appeal/reassignment audit
- `merge_reason`, `audit_status`, `audit_resolution`, `audit_source_page`, `winner_members_confidence` — provenance and confidence

### indecopi_080_firm_process_roles.csv  (199 firm-process rows)
- `process_id_master`, `firm_canonical` — tender and firm
- `role_class` — winning-consortium member / cover bidder / cover bidder of uncertain target / participant without support
- `won` — 1 if firm is in the winning consortium
- `source_exhibits`, `n_independent_exhibits` — evidence intensity (how many exhibits document the role)

### indecopi_080_firm_sanctions.csv  (32 economic groups)
- `firm_canonical`, `legal_name_in_resolution`, `economic_group`, `ruc` — firm identity (public)
- `role_in_cartel`, `conduct_start`, `conduct_end`, `market_or_project_scope` — sanctioned conduct
- `sanctioned`, `status`, `fine_uit`, `fine_note` — outcome and fine in UIT
- `remedial_obligations`, `leniency_or_cooperation`, `appeal_status`, `source_page` — remedies, cooperation, provenance

### firm_exposure_indecopi.csv
- `firm_canonical`; `n_processes_documented`, `n_won`, `n_cover_bidder`, `n_no_support` — counts by role
- `cartelized_ref_value_won`, `cartelized_ref_value_won_coverage` — value of tenders won (partial coverage)

### anexo2_bids.csv  (offer-level)
- `process_raw`, `process_id` — tender code
- `tipo` — **colluded / competitive** classification (the adjudicated label, *tipo de oferta*)
- `grupo`, `empresa`, `consorcio` — bidding group, firm, consortium
- `won` — winning bid; `vr`, `vo` — reference and offered value
- `page`, `row`, `fecha` — provenance in the resolution

### indecopi_resolution_080_2021_verified_database.xlsx
QA'd transcription of the resolution. Sheets: `Anexo2_571` (offer-level bids with `tipo_proceso`, qa_status),
`Processes_112` (reference values), `Anexo3_MultaBase` (reference value, **illicit benefit**, base fine per
process-firm), QA-by-page sheets, and a `Data_Dictionary` sheet.
