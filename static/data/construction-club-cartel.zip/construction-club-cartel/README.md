# The Construction Club Cartel — Reconstructed Dataset

Bid-rigging in Peruvian national road procurement, reconstructed from the public antitrust ruling
**Resolución 080-2021/CLC-INDECOPI** (15 November 2021), which sanctioned thirty-two construction groups for a
horizontal bid-rigging agreement in Ministry of Transport road tenders between **November 2002 and December
2016**.

This is the tender-and-firm universe behind the paper *The Price of Corruption: Evidence from Lava Jato and the
Construction Club in Peru* (Chávez Padilla, 2026). It is the realized assignment that the collusion-detection
literature usually has to infer from bid distributions: the competition authority adjudicated each tender, so
the colluded/competitive label is observed.

All tables are **firm-level** and built entirely from the public resolution. No personal data is included.

## Files
| file | rows | contents |
|---|---|---|
| `indecopi_080_process_union_all_exhibits.csv` | 78 | the reconstructed tender universe: process code, year, project, winner and members, reference and offered values, source exhibits |
| `indecopi_080_firm_process_roles.csv` | 199 | firm × process roles (winning-consortium member, cover bidder, cover bidder of uncertain target, participant without support) |
| `indecopi_080_participants_all_exhibits.csv` | — | participant-level rows underlying the roles |
| `indecopi_080_process_winners.csv` | — | designated and observed winners per process, with appeal/chronology notes |
| `indecopi_080_firm_sanctions.csv` | 32 | sanctioned economic groups: RUC, role, conduct start/end, fine (UIT), remedial obligations, cooperation |
| `firm_exposure_indecopi.csv` | — | firm-level cartel exposure (won, covered, cartelized value) |
| `process_exposure_indecopi.csv` | — | process-level evidence intensity |
| `anexo2_bids.csv` | — | offer-level bids from Anexo 2, with the colluded/competitive classification (`tipo de oferta`) |
| `anexo2_road_processes.csv` | — | MTC/20 road processes with the colluded/competitive label, matched to SEACE obra |
| `indecopi_080_seace_crosscheck_78.csv` | — | validation against Peru's open procurement records (SEACE/OCDS) |
| `indecopi_080_name_crosswalk.csv` | — | firm name normalization (group ↔ subsidiaries ↔ resolution legal name) |
| `indecopi_resolution_080_2021_verified_database.xlsx` | — | the QA'd transcription of the resolution (Anexo 2 bids, Anexo 3 illicit benefit and fines, Processes-112 reference values, data dictionary) |

See `DATA_DICTIONARY.md` for column definitions.

## Source
Indecopi, *Resolución 080-2021/CLC-INDECOPI*, Expediente 001-2020/CLC, 15 November 2021 (public). The dataset
is a derived reconstruction of that ruling.

## Citation
Chávez Padilla, Carlos César. 2026. "The Price of Corruption: Evidence from Lava Jato and the Construction Club
in Peru." Working paper. Dataset: *The Construction Club Cartel — Reconstructed Dataset.*

## License
Data released under **Creative Commons Attribution 4.0 (CC BY 4.0)**. See `LICENSE.txt`.
